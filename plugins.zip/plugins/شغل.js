const { generateWAMessageFromContent, prepareWAMessageMedia } = (await import('baileys-pro')).default;
import yts from 'yt-search';

let handler = async (m, { conn, usedPrefix, command, text }) => {
   if (!text) return m.reply(
`╭┈➤💫 *${conn.getName(conn.user.jid)}* يـرحـب بـك 🧭
╰┈──────────── ೄྀ࿐ ˊˎ-

╭┈➤ 📌 *اكتـب اسـم مـا تـريـد بـحـثـه* 🎶
│
│˖ ۬.͜ـ✘ *مثال:*
│➤ ${usedPrefix + command} القرآن الكريم
│➤ ${usedPrefix + command} أغنية هادئة
│
╰ׅ᳝࣪✿⵿࣪ ┈֟፝͜╾᪶⃜┈ ࣪•📌•࣪ ┈╼࣪֟፝͜✿⵿᳝╯
╭┈──────────── ೄྀ࿐ ˊˎ-`
   );

   try {
      await m.react('🔍');

      let search = await yts(text);
      let video = search.all[0];
      let linkyt = video.url;

      let teksnya = 
`╭┈➤✨ *نـتـيـجـة الـبـحـث* ✨
╰┈──────────── ೄྀ࿐ ˊˎ-

╭ׅ᳝࣪✿⵿࣪ ┈֟፝͜┅↜معلومـات↝┅֟፝͜╾᪶⃜┈࣪✿⵿᳝╮
│˖ ۬.͜ـ✘ 🎬 *العنـوان:* ${video.title}
│˖ ۬.͜ـ✘ 👁️ *المشاهدات:* ${video.views}
│˖ ۬.͜ـ✘ ⏳ *المدة:* ${video.timestamp}
│˖ ۬.͜ـ✘ 📆 *النشر:* ${video.ago}
│˖ ۬.͜ـ✘ 🔗 *الرابـط:* ${linkyt}
╰ׅ᳝࣪✿⵿࣪ ┈֟፝͜┅↜الـخـيـارات↝┅֟፝͜╾᪶⃜┈࣪✿⵿᳝╯`;

      const { imageMessage } = await prepareWAMessageMedia(
         { image: { url: video.thumbnail } },
         { upload: conn.waUploadToServer }
      );

      const messageContent = {
         buttonsMessage: {
            contentText: teksnya,
            footerText: '✨ ' + conn.getName(conn.user.jid) + ' ✨',
            buttons: [
               {
                  buttonId: `.اغنيه ${video.url}`,
                  buttonText: { displayText: '🎵 صوت' },
                  type: 1
               },
               {
                  buttonId: `.ريك ${video.url}`,
                  buttonText: { displayText: '🎵 صوت احتياطي' },
                  type: 1
               },
               {
                  buttonId: `.تحمل ${video.url}`,
                  buttonText: { displayText: '🎶 صوت احطياتي' },
                  type: 1
               },
               {
                  buttonId: `.فيديو ${video.url}`,
                  buttonText: { displayText: '⏱️ فيديو' },
                  type: 1
               },
               {
                  buttonId: `.يوتيوب ${video.url}`,
                  buttonText: { displayText: '🎥 احطياتي فيديو' },
                  type: 1
               }
            ],
            headerType: 4,
            imageMessage: imageMessage
         }
      };

      const message = generateWAMessageFromContent(
         m.chat,
         { ephemeralMessage: { message: messageContent } },
         { userJid: conn.user.id }
      );

      await conn.relayMessage(m.chat, message.message, { messageId: m.key.id });
      await m.react('✅');

   } catch (error) {
      console.error("⚠️ خطأ:", error);
      await m.react('❌');
      await conn.sendMessage(m.chat, {
         text: 
`╭┈➤‼️ *حدث خطأ أثناء البحث* ‼️
╰┈──────────── ೄྀ࿐ ˊˎ-

╭ׅ᳝࣪✿⵿࣪ ┈֟፝͜┅↜التفاصيل↝┅֟፝͜╾᪶⃜┈࣪✿⵿᳝╮
│˖ ۬.͜ـ✘ لم يتم العثور على نتائج.
│˖ ۬.͜ـ✘ يرجى المحاولة بكلمة أخرى.
╰ׅ᳝࣪✿⵿࣪ ┈֟፝͜┅↜انتهى↝┅֟፝͜╾᪶⃜┈࣪✿⵿᳝╯`
      });
   }
};

handler.help = ['تشغيل'].map(v => v + ' <اسم الأغنية/الفيديو>');
handler.tags = ['تحميل'];
handler.command = /^(اغنية|اغنيه|شغل)$/i;

export default handler;