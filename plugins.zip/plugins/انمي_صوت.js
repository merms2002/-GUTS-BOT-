import axios from "axios";

let voices = {
  "takumi": "Takumi",
  "mizuki": "Mizuki",
  "haruka": "Haruka",
  // أنمي أصوات مضافة
  "goku": "Goku",
  "gojo": "Gojo",
  "hatsuyuki": "Hatsuyuki",
  "miku": "Miku",
  "ofi": "Ofi",
  "zoro": "Zoro",
  "alastor": "Alastor", // Hazbin Hotel
};

let handler = async (m, { args, conn }) => {
  if (args.length < 2) return m.reply("❌ الاستخدام: .tts <الشخصية> <النص>");

  const character = args[0].toLowerCase();
  const text = args.slice(1).join(" ");

  if (!voices[character]) return m.reply("❌ الصوت غير متوفر.");

  try {
    const audioBuffer = await getTTS(text, voices[character]);
    if (!audioBuffer) return m.reply("❌ فشل تحويل النص لصوت.");

    await conn.sendMessage(
      m.chat,
      { audio: audioBuffer, mimetype: "audio/mpeg", ptt: true },
      { quoted: m }
    );
  } catch (error) {
    console.error("TTS Error:", error);
    m.reply("❌ حدث خطأ أثناء تحويل النص لصوت.");
  }
};

handler.help = ["tts"];
handler.tags = ["tools"];
handler.command = ["tts", "انمي_صوت"];

export default handler;

// 🟢 طلب مباشر باستخدام headers
async function getTTS(text, voice = "Takumi") {
  try {
    let { data } = await axios.post(
      "https://ttsmp3.com/makemp3_new.php",
      new URLSearchParams({
        msg: text,
        lang: voice,
        source: "ttsmp3",
      }),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
          Referer: "https://ttsmp3.com/",
        },
      }
    );

    if (!data || !data.URL) throw new Error("No audio URL returned");

    let res = await axios.get(data.URL, { responseType: "arraybuffer" });
    return Buffer.from(res.data);
  } catch (err) {
    console.error("Direct TTS Error:", err.message);
    return null;
  }
}