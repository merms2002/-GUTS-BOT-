function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

import pkg from 'baileys-pro';
const { generateWAMessageFromContent, prepareWAMessageMedia } = pkg;

let rtotalreg = Object.keys(global.db.data.users).length;
let now = new Date();
let week = now.toLocaleDateString('ar-TN', { weekday: 'long' });
let time = now.toLocaleDateString('ar-TN', { year: 'numeric', month: 'long', day: 'numeric' });

const handler = async (m, { conn }) => {
    try {
        let uptime = clockString(process.uptime() * 1000);
        let user = global.db.data.users[m.sender] || {};
        let { role, level } = user;
        let mentionId = m.key.participant || m.key.remoteJid;

        await conn.sendMessage(m.chat, { react: { text: '🎶', key: m.key } });

        const radio = 'https://files.catbox.moe/cxw6km.jpg';
        const media = await prepareWAMessageMedia({ image: { url: radio } }, { upload: conn.waUploadToServer });

        let message = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "gataVidMenu" },
                        body: { 
                            text: `*◞💎‟⌝╎مـرحـبـا بـك يا ⇝ @${mentionId.split('@')[0]} ⸃⤹*  
*~⌝˼‏※⪤˹͟͞≽⌯⧽°⸂◞🤖◜⸃°⧼⌯≼˹͟͞⪤※˹⌞~*
*⌝💻╎معلومـات البوت: ⌞*  
> *╭*  
> *┊ 🤖╎اســم الـبـوت: ABYSS*  
> *┊ 👑╎المطور: ⌗𝑅𝐴𝐷𝐼𝛩*  
> *┊ 📞╎رقـم المـطور: +201500564191*  
> *┊ 🗓╎الـيـوم: ${week}*  
> *┊ 📆╎التـاريـخ: ${time}*  
> *╰*
*⌝📚╎معلومـاتـك: ⌞*  
> *╭*  
> *┊ 🏅╎مستواك: ${level}*  
> *┊ 🎖╎رتبـتك: ${role}*  
> *┊ 🌍╎عـدد المستخدمين: ${rtotalreg}*  
> *╰*
*~⌝˼‏※⪤˹͟͞≽⌯⧽°⸂◞🌟◜⸃°⧼⌯≼˹͟͞⪤※˹⌞~*` 
                        },
                        header: { hasMediaAttachment: true, ...media },
                        contextInfo: { mentionedJid: [m.sender], isForwarded: false },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '⌝📚╎قـسـام الأوامـر: ⌞',
                                        sections: [
                                            {
                                                title: '⌝🐣╎قـسـام البـوت: ⌞',
                                                highlight_label: 'ABYSS BOT',
                                                rows: [
                                                    { header: '⌝👑╎القسم الأول: ⌞', title: '⌝🍬╎「قسم_الألعاب」⌞', id: '.ق1' },
                                                    { header: '⌝🔥╎القسم الثاني: ⌞', title: '⌝🍭╎「قسم_المشرفين」⌞', id: '.ق2' },
                                                    { header: '⌝🛠╎القسم الثالث: ⌞', title: '⌝🔧╎「قسم_الأدوات」⌞', id: '.ق3' },
                                                    { header: '⌝⬇️╎القسم الرابع: ⌞', title: '⌝📥╎「قسم_التحميل」⌞', id: '.ق4' },
                                                    { header: '⌝🎮╎القسم الخامس: ⌞', title: '⌝🏦╎「قسم_البنك」⌞', id: '.ق5' },
                                                    { header: '⌝🤖╎القسم السادس: ⌞', title: '⌝🧠╎「قسم_AI」⌞', id: '.ق6' },
                                                    { header: '⌝🎉╎القسم السابع: ⌞', title: '⌝😂╎「قسم_التسلية」⌞', id: '.ق7' },
                                                    { header: '⌝🕌╎القسم الثامن: ⌞', title: '⌝📿╎「قسم_الدين」⌞', id: '.ق8' },
                                                    { header: '⌝🖌╎القسم التاسع: ⌞', title: '⌝✨╎「قسم_الزخارف」⌞', id: '.ق9' },
                                                    { header: '⌝⚔️╎القسم العاشر: ⌞', title: '⌝🏰╎「قسم_النقابات」⌞', id: '.ق10' },
                                                    { header: '⌝🖼╎القسم 11: ⌞', title: '⌝🌅╎「قسم_الصور」⌞', id: '.ق11' },
                                                    { header: '⌝🙂╎القسم 12: ⌞', title: '⌝😎╎「قسم_الوجوهات」⌞', id: '.ق12' },
                                                    { header: '⌝📜╎القسم الخاص: ⌞', title: '⌝⚖️╎「القوانين」⌞', id: '.القواعد' }
                                                ]
                                            }
                                        ]
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: '{"display_text":"⌝📲╎قناة المطور⌞","url":"https://whatsapp.com/channel/0029VaumDtWJZg4B8jLyMK2q"}'
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: '{"display_text":"⌝🚀╎المطور⌞","id":".المطور"}'
                                }
                            ]
                        }
                    }
                }
            }
        };

        const msg = generateWAMessageFromContent(m.chat, message, { userJid: m.sender });
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error(err);
    }
};

// 🛠️ هنا نفس طريقة الأصلي
handler.help = ['منيو', 'menu'];
handler.tags = ['main'];
handler.command = ['menu', 'مهام', 'اوامر', 'الاوامر', 'قائمة', 'القائمة'];

export default handler;