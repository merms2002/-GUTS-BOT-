import fs from 'fs';
import path from 'path';

let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let taguser = '@' + m.sender.split("@")[0];

  // قراءة ملف روابط الصور
  const linksFile = './media-links.txt';
  if (!fs.existsSync(linksFile)) return await m.reply('⚠️ ملف روابط الصور غير موجود.');
  const links = fs.readFileSync(linksFile, 'utf-8').split('\n').filter(Boolean);
  if (!links.length) return await m.reply('⚠️ ملف روابط الصور فارغ.');

  // اختيار صورة عشوائية
  const randomImageUrl = links[Math.floor(Math.random() * links.length)];

  let message = `
╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊${taguser}⌉
── • ◈ • ──
*⌝⛄┊قــســم الـالـعـاب┊🧸⌞* 
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹✨›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
┤┌ ─๋︩︪─✦الالعاب☇─˚᳝᳝𖥻
│┊ ۬.͜ـ🧸˖ ⟨احزر☇ 
│┊ ۬.͜ـ🧸˖ ⟨عين☇
│┊ ۬.͜ـ🧸˖ ⟨لعبه☇
│┊ ۬.͜ـ🧸˖ ⟨عاصمه☇
│┊ ۬.͜ـ🧸˖ ⟨اكس او☇
│┊ ۬.͜ـ🧸˖ ⟨كت☇
│┊ ۬.͜ـ🧸˖ ⟨فكك☇
│┊ ۬.͜ـ🧸˖ ⟨سؤال☇
│┊ ۬.͜ـ🧸˖ ⟨علم☇
│┊ ۬.͜ـ🧸˖ ⟨عين☇
│┊ ۬.͜ـ🧸˖ ⟨ايموجي☇
│┊ ۬.͜ـ🧸˖ ⟨تاريخ☇
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹♻️›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ  `;

  const emojiReaction = '🪭';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    await conn.sendMessage(m.chat, { 
      image: { url: randomImageUrl },
      caption: message,
      mentions: [m.sender]
    });
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق1)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;