import puppeteer from "puppeteer";

let handler = async (m, { conn }) => {
  try {
    const browser = await puppeteer.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });

    const page = await browser.newPage();
    await page.goto("https://uberduck.ai/speak", { waitUntil: "networkidle2" });

    // انتظر 10 ثواني لتسجيل الدخول لو لزم (تقدر تعدل)
    await page.waitForTimeout(10000);

    const cookies = await page.cookies();

    if (!cookies || cookies.length === 0) {
      await m.reply("❌ فشل الحصول على الكوكيز. حاول تسجيل الدخول أولاً.");
      await browser.close();
      return;
    }

    // تحويل الكوكيز لسلسلة جاهزة للهيدر
    const cookieString = cookies.map(c => `${c.name}=${c.value}`).join("; ");

    await m.reply(`✅ تم الحصول على الكوكيز:\n\n${cookieString}`);
    await browser.close();
  } catch (err) {
    console.error(err);
    await m.reply("❌ حصل خطأ أثناء محاولة جلب الكوكيز.");
  }
};

handler.help = ["كوكيز"];
handler.tags = ["dev"];
handler.command = ["getcookies", "كوكيز"];

export default handler;