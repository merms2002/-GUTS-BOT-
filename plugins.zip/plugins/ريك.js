import axios from "axios";
import yts from "yt-search";

const apiBaseUrl = "https://p.oceansaver.in/ajax";

const downloadMedia = async (url) => {
  const apiUrl = `${apiBaseUrl}/download.php?format=mp3&url=${encodeURIComponent(url)}&api=YOUR_API_KEY`;

  try {
    const { data } = await axios.get(apiUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (!data || !data.success) throw new Error('✘︙فشل الحصول على تفاصيل الفيديو.');
    return await checkProgress(data.id);
  } catch (error) {
    throw new Error(`✘︙خطأ أثناء التنزيل: ${error.message}`);
  }
};

const checkProgress = async (id) => {
  const progressUrl = `${apiBaseUrl}/progress.php?id=${id}`;
  let attempts = 0;
  const maxAttempts = 30;

  while (attempts < maxAttempts) {
    const { data } = await axios.get(progressUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } });
    if (data && data.success && data.progress === 1000) {
      return data.download_url;
    }
    attempts++;
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  throw new Error('✘︙العملية استغرقت وقتًا طويلاً.');
};

const handler = async (m, { conn, text }) => {
  if (!text || text.trim().length < 2) {
    return m.reply(
`╭┈➤💫 *اكتب اسم الأغنية بشكل أوضح* 🎶
╰┈──────────── ೄྀ࿐ ˊˎ-`
    );
  }

  try {
    const search = await yts(text);
    const video = search.all[0];
    if (!video) return m.reply('╭┈➤💫 لم يتم العثور على نتائج!\n╰┈──────────── ೄྀ࿐ ˊˎ-');

    const detail = 
`╭┈➤🎧 *تفاصيل الأغنية* 🎶
╰┈──────────── ೄྀ࿐ ˊˎ-

╭ׅ᳝࣪✿⵿࣪ ┈֟፝͜┅↜معلـومـات↝┅֟፝͜╾᪶⃜┈࣪✿⵿᳝╮
│˖ ۬.͜ـ✘ 🎬 *العنوان:* ${video.title || 'غير متوفر'}
│˖ ۬.͜ـ✘ 🧾 *الوصف:* ${video.description || 'غير متوفر'}
│˖ ۬.͜ـ✘ ⏳ *المدة:* ${video.timestamp || 'غير متوفر'}
│˖ ۬.͜ـ✘ 📅 *منذ:* ${video.ago || 'غير متوفر'}
│˖ ۬.͜ـ✘ 🎙️ *القناة:* ${video.author.name || 'غير متوفر'}
╰ׅ᳝࣪✿⵿࣪ ┈֟፝͜┅↜🎵↝┅֟፝͜╾᪶⃜┈࣪✿⵿᳝╯

⊛ 𝙁𝙤𝙧𝙞𝙣𝙖 𝘽𝙤𝙩 • 🎧
`.trim();

    await conn.sendMessage(m.chat, {
      text: detail,
      contextInfo: {
        externalAdReply: {
          title: video.title,
          body: "📥 تحميل من YouTube",
          thumbnailUrl: video.thumbnail,
          mediaUrl: video.url,
          renderLargerThumbnail: true,
          showAdAttribution: true,
        }
      }
    }, { quoted: m });

    const downloadUrl = await downloadMedia(video.url);
    if (!downloadUrl) return m.reply('╭┈➤💫 فشل تحميل الصوت.\n╰┈──────────── ೄྀ࿐ ˊˎ-');

    await conn.sendMessage(m.chat, {
      audio: { url: downloadUrl },
      mimetype: 'audio/mpeg',
      ptt: true,
    }, { quoted: m });

  } catch (error) {
    m.reply(`╭┈➤💥 *حدث خطأ!*\n╰┈──────────── ೄྀ࿐ ˊˎ-\n\n✘︙${error.message}`);
  }
};

handler.help = ['اغنية <اسم الأغنية>'];
handler.tags = ['بحث', 'صوت'];
handler.command = /^(ريك)$/i;

export default handler;