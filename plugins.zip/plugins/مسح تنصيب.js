import { readdirSync, statSync, unlinkSync, existsSync, readFileSync, watch, rmSync, promises as fs} from "fs"
import path, { join } from 'path'

let handler  = async (m, { conn, usedPrefix, command}, args) => {
let parentw = conn
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let uniqid = `${who.split`@`[0]}`
let userS = `${conn.getName(who)}`

    const tr = async (text) => {
  const translations = {
    "Que está buscando?": "ماذا تبحث؟",
    "Ingrese el nombre de la canción": "أدخل اسم الأغنية",
    "Ejemplo:": "مثال:",
    "Hey": "مرحبًا",
    "espera pendejo, ya estás descargando algo": "انتظر قليلًا، أنت تقوم بتحميل شيء حاليًا",
    "Espera a que termine tu solicitud actual antes de hacer otra...": "انتظر حتى تنتهي طلباتك الحالية قبل إرسال طلب آخر",
    "Duración": "المدة",
    "Aguarde un momento en lo que envío su": "انتظر لحظة أثناء إرسال"
  };
  return translations[text] || text; // ترجمة النص إذا كان موجودًا في القاموس، وإلا يتم إرجاع النص كما هو
};
if (global.conn.user.jid !== conn.user.jid) {
return conn.sendMessage(m.chat, {text: `*⚠️ ${await tr("USE ESTE COMANDO AL BOT PRINCIPAL")}*\n\nwa.me/${global.conn.user.jid.split`@`[0]}&text=${usedPrefix + command}`}, { quoted: m }) 
} else {
try {
await fs.rmdir("./jadibts/" + uniqid, { recursive: true, force: true })
await conn.sendMessage(m.chat, { text: `*${await tr("TE VOY A EXTRAÑAR")} ${wm} ${await tr("CHAOO!!")} 🥹*` }, { quoted: m })
await conn.sendMessage(m.chat, { text : await tr(`*⚠️ HA CERRADO SESIÓN Y BORRADO TODO RASTRO*`) } , { quoted: m })
} catch(err) {
if (err.code === 'ENOENT' && err.path === `./jadibts/${uniqid}`) {
await conn.sendMessage(m.chat, { text: await tr("⚠️ Usted no es un Sub-Bot") }, { quoted: m })
} else {
console.error(userS + ' ' + await tr(`⚠️ HA CERRADO SESIÓN COMO SUB BOT`), err)
}}}
}
handler.help = ['deletesession', 'eliminarsesion'];
handler.tags = ['jadibot'];
handler.command = /^(deletesess?ion|eliminarsesion|borrarsesion|delsess?ion|cerrarsesion)$/i
handler.private = true
handler.fail = null

export default handler