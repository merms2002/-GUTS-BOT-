import axios from "axios";

const voicesList = {
  "مصر": "Omar",       // صوت عربي ذكر
  "عربي": "Zeina",     // صوت عربي أنثى
  "zeina": "Zeina",
  "omar": "Omar"
};

let handler = async (m, { args, conn }) => {
  if (args.length < 2) return m.reply("❌ الاستخدام: .صوت <الصوت> <النص>");

  const voiceName = args[0];
  const text = args.slice(1).join(" ");

  const voice = voicesList[voiceName.toLowerCase()];
  if (!voice) return m.reply("❌ الصوت غير موجود. الأصوات المتاحة: " + Object.keys(voicesList).join(", "));

  try {
    const audioBuffer = await generateFreeTTS(text, voice);
    if (!audioBuffer) return m.reply("❌ فشل تحويل النص لصوت.");

    await conn.sendMessage(
      m.chat,
      { audio: audioBuffer, mimetype: "audio/mpeg", ptt: true },
      { quoted: m }
    );
  } catch (err) {
    console.error("FreeTTS Error:", err);
    m.reply("❌ حدث خطأ أثناء تحويل النص لصوت.");
  }
};

handler.help = ["صوت"];
handler.tags = ["tools"];
handler.command = ["عربي"];
export default handler;

// 🌐 دالة تحويل النص لصوت باستخدام freetts.com
async function generateFreeTTS(text, voice) {
  try {
    const { data } = await axios.post(
      "https://www.freetts.com/Home/Generate",
      new URLSearchParams({
        Text: text,
        Voice: voice,
        Language: "ar",
        Format: "mp3"
      }),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
          Referer: "https://www.freetts.com/",
        },
        responseType: "arraybuffer"
      }
    );

    return Buffer.from(data);
  } catch (err) {
    console.error("FreeTTS Direct Error:", err.message);
    return null;
  }
}