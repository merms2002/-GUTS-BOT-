import pkg from 'baileys-pro';
const { generateWAMessageFromContent, prepareWAMessageMedia } = pkg;

let handler = m => m;

handler.all = async function (m) {
  if (m.key.fromMe) return;

  let chat = global.db.data.chats[m.chat];
  if (chat.isBanned) return;

  const sendAdReply = async (text) => {
    const buttons = [
      {
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
          display_text: '⌈🚀╎المطور╎🚀⌋',
          id: '.المطور'
        })
      },
      {
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
          display_text: '⌈🧩╎الاوامر╎🧩⌋',
          id: '.الاوامر'
        })
      }
    ];

    const message = generateWAMessageFromContent(m.chat, {
      extendedTextMessage: {
        text: text,
        contextInfo: {
          externalAdReply: {
            title: "𝙱𝚈 𝚁𝙰𝙳𝙸𝙾 𝙳𝙴𝙼𝙾𝙽",
            body: "𝐀𝐁𝐘𝐒𝐒|𝐁𝐎𝐓",
            thumbnailUrl: "https://raw.githubusercontent.com/RADIOdemon6-alt/uploading-/main/uploads/upload-1750150463777.jpg",
            sourceUrl: "https://whatsapp.com/channel/0029VaENL4h1lD3MZsVEty",
            mediaType: 1,
            showAdAttribution: true,
            renderLargerThumbnail: false
          },
          buttonReply: buttons[0], // الزر الأول يظهر تلقائيًا
          buttons
        }
      }
    }, { quoted: m });

    await conn.relayMessage(m.chat, message.message, { messageId: message.key.id });
  };

  if (/^احا$/i.test(m.text)) await sendAdReply("*خدها و شلحها😆*");
  if (/^هاو تو$/i.test(m.text)) await sendAdReply("*نـعـم انـا هـنـا*");
  if (/^الحمدلله$/i.test(m.text)) await sendAdReply("*ادام الله حمدك*");
  if (/^عبيط|يا عبيط|اهبل|غبي$/i.test(m.text)) await sendAdReply("*انت يبيبي 🥲❤️*");
  if (/^بوت$/i.test(m.text)) await sendAdReply("*ارغي عايز ايه*");
  if (/^يب$/i.test(m.text)) await sendAdReply("*يعم استرجل وقول نعم 🐦❤*");
  if (/^الاستور$/i.test(m.text)) await sendAdReply("*مطوري و حبيبي😊*");
  if (/^بوت خرا|بوت زفت|خرا عليك$/i.test(m.text)) await sendAdReply("*بص يسطا لم نفسك بدل ما انسي اني بنت و امسح بيك بلاط الشات😒🗿*");
  if (/^منور|منوره$/i.test(m.text)) await sendAdReply("*بنوري انا 🫠💔*");
  if (/^بنورك|دا نورك|نورك الاصل|نور نورك$/i.test(m.text)) await sendAdReply("*يعم بنوري انا 🫠🐦*");
  if (/^امزح|بهزر$/i.test(m.text)) await sendAdReply("*دمك تقيل متهزرش تاني😒*");
  if (/^في ايه$/i.test(m.text)) await sendAdReply("*انا معرفش حاجه🙂*");
  if (/^تست$/i.test(m.text)) await sendAdReply("*موجوده عايز ايه🗿*");
  if (/^بتعمل ايه دلوقتي|بتعمل اي$/i.test(m.text)) await sendAdReply("*انت مالك😒*");
  if (/^انا جيت$/i.test(m.text)) await sendAdReply("*امشي تاني*");
  if (/^حرامي|سارق$/i.test(m.text)) await sendAdReply("*تتهم بريء بالسرقة ... فبسكوتك اقتل جهلك*");
  if (/^ملل|مللل|ملللل|زهق$/i.test(m.text)) await sendAdReply("*لانك موجود🗿*");
  if (/^🤖$/i.test(m.text)) await sendAdReply("انت بوت عشان ترسل الملصق ده 🐦");
  if (/^🐦‍⬛$/i.test(m.text)) await sendAdReply("🐦");
  if (/^ايه$/i.test(m.text)) await sendAdReply("*بلاش ارد احسن🌝🤣*");
  if (/^نعم$/i.test(m.text)) await sendAdReply("*حد ناداك 🌚🐦*");
  if (/^كيفك|شخبارك|علوك|عامل ايه|اخبارك|اي الدنيا$/i.test(m.text)) await sendAdReply("*⛄جـيـده وانـت؟*");
  if (/^🐤$/i.test(m.text)) await sendAdReply("🐦");
  if (/^تصبح علي خير|تصبحوا علي خير$/i.test(m.text)) await sendAdReply("وانت من اهل الخير حبيبي✨💜");
  if (/^ببحبك بوت|حبك|بوت بحبك$/i.test(m.text)) await sendAdReply("🙄");
  if (/^🙂$/i.test(m.text)) await sendAdReply("بص بعيد🙂");
  if (/^باي$/i.test(m.text)) await sendAdReply("*مـع الـسـلامـه🐥*");
  if (/^هلا$/i.test(m.text)) await sendAdReply("*اهـلا كـيـفـك🧸*");

  return !0;
};

export default handler;