import fs from 'fs';
import path from 'path';

let handler = async (m, { conn }) => {
  const pluginDir = './plugins';
  const mediaFolder = './media';

  // دالة توليد كود البلوجن
  const generatePluginContent = (command_name) => `
import fs from 'fs';
import path from 'path';
import pkg from 'baileys-pro';
const { prepareWAMessageMedia } = pkg;

let handler = async (m, { conn }) => {
  try {
    const taguser = '@' + m.sender.split('@')[0];

    const files = fs.readdirSync('${mediaFolder}').filter(file => /\\.(jpg|jpeg|png|webp)$/i.test(file));
    if (!files.length) throw '⚠️ لا توجد صور في مجلد media.';

    const randomImage = path.join('${mediaFolder}', files[Math.floor(Math.random() * files.length)]);
    const media = await prepareWAMessageMedia(
      { image: fs.readFileSync(randomImage) },
      { upload: conn.waUploadToServer }
    );

    const message = {
      interactiveMessage: {
        header: {
          hasMediaAttachment: true,
          ...media
        },
        body: {
          text: \`📋 هذه قائمة ${command_name} للمستخدم: \${taguser}\`
        },
        nativeFlowMessage: {
          buttons: [
            { name: 'quick_reply', buttonParamsJson: '{"display_text":"رجوع ⬅️","id":".menu"}' }
          ]
        },
        contextInfo: { mentionedJid: [m.sender], isForwarded: false }
      }
    };

    await conn.relayMessage(m.chat, message, {});

  } catch (err) {
    console.error(err);
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m });
  }
};

handler.command = /^${command_name}$/i;
handler.exp = 50;
handler.fail = null;

export default handler;
`;

  let count = 0;
  fs.readdirSync(pluginDir).forEach(file => {
    if (/^ق\d+\.js$/.test(file)) {
      const commandName = file.replace('.js', '');
      const newContent = generatePluginContent(commandName);
      fs.writeFileSync(path.join(pluginDir, file), newContent, 'utf-8');
      count++;
    }
  });

  await conn.sendMessage(m.chat, { text: `✅ تم تعديل ${count} ملف من ملفات الأقسام بنجاح!` }, { quoted: m });
};

handler.command = /^تعديل_الاقسام$/i;
handler.owner = true;  // خلي الامر للمطور فقط

export default handler;