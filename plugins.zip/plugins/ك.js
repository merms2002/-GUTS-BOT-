import axios from "axios";

let handler = async (m, { args }) => {
  if (!args[0]) return m.reply("❌ اكتب النص اللي تحب تحوله بصوت أنمي.");

  let text = args.join(" ");

  try {
    let audioBuffer = await fakeyouTTS(text, "goku"); // صوت غوكو مثال
    if (!audioBuffer) return m.reply("❌ فشل تحويل النص لصوت.");

    await conn.sendMessage(
      m.chat,
      { audio: audioBuffer, mimetype: "audio/mpeg", ptt: true },
      { quoted: m }
    );
  } catch (err) {
    console.error("Anime TTS Error:", err.message);
    m.reply("❌ حصل خطأ أثناء تحويل النص لصوت.");
  }
};

handler.help = ["انمي_صوت"];
handler.tags = ["fun"];
handler.command = ["تست"];

export default handler;

// 🟢 FakeYou API (غير رسمي)
async function fakeyouTTS(text, voice = "goku") {
  try {
    // ID للصوت (مثلاً غوكو / هاتسوني ميكو / غوجو...)
    let voiceMap = {
      goku: "TM:7x3x5m5f5r4d", // ID لصوت غوكو
      miku: "TM:8f8f8f8f8f8f", // مثال (هاتسوني ميكو)
      gojo: "TM:1a2b3c4d5e6f", // مثال (غوجو)
    };

    let voiceId = voiceMap[voice] || voiceMap["goku"];

    // 1- نطلب إنشاء الصوت
    let { data } = await axios.post(
      "https://api.fakeyou.com/tts/inference",
      {
        tts_model_token: voiceId,
        inference_text: text,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "Mozilla/5.0",
        },
      }
    );

    if (!data || !data.inference_job_token)
      throw new Error("مافيش job token راجع");

    let jobToken = data.inference_job_token;

    // 2- نستنى لحد ما يجهز الصوت
    let audioUrl;
    for (let i = 0; i < 20; i++) {
      await new Promise((r) => setTimeout(r, 3000));
      let job = await axios.get(
        `https://api.fakeyou.com/tts/job/${jobToken}`
      );
      if (job.data?.state?.status === "complete_success") {
        audioUrl = "https://storage.googleapis.com/vocodes-public" + job.data.state.maybe_public_bucket_wav_audio_path;
        break;
      }
    }

    if (!audioUrl) throw new Error("الصوت ماجهزش");

    // 3- نجيب الصوت كـ Buffer
    let res = await axios.get(audioUrl, { responseType: "arraybuffer" });
    return Buffer.from(res.data);
  } catch (err) {
    console.error("FakeYou Error:", err.message);
    return null;
  }
}