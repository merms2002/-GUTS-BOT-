import yts from 'yt-search';

let handler = async (m, { conn, text }) => {
  try {
    if (!text) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key }});
      return conn.reply(m.chat, 
`╭─︿︿︿︿︿︿︿︿╮
│✍️ أُكْتُبْ اسـم الأُغْنِيَة بَعْدَ الأمْر:
│مثال: .اغنيه lavender haze
╰─﹀﹀﹀﹀﹀﹀﹀﹀╯`, m);
    }

    // ⏳ تفاعل الانتظار
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key }});

    const search = await yts(text);
    if (!search.videos.length) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key }});
      return conn.reply(m.chat, '❌ لَمْ أَجِدْ أُغْنِيَةً بِهَذَا الإِسْمِ', m);
    }

    const video = search.videos[0];
    const title = video.title;
    const artist = video.author.name;
    const url = video.url;
    const duration = video.timestamp;
    const thumbnail = video.thumbnail;

    const caption = `
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹✨›⊏═┈ ─๋︩︪─
⊰ـ ┤┌─๋︩︪─✦المعلومات☇─˚𖥻
│┊ ۬.͜ـ🎵˖ ⟨الاسم: ${title}⟩
│┊ ۬.͜ـ🎙️˖ ⟨الفنان: ${artist}⟩
│┊ ۬.͜ـ⏱️˖ ⟨المدة: ${duration}⟩
│┊ ۬.͜ـ🔗˖ ⟨الرابط: ${url}
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹✅›⊏═┈ ─๋︩︪─
⊰ـ`;

    await conn.sendMessage(m.chat, {
      image: { url: thumbnail },
      caption: caption,
      buttons: [
        {
          buttonId: `.تحمل ${url}`,
          buttonText: {
            displayText: '⬇️ تـحـمـيـل'
          },
          type: 1
        }
      ],
      viewOnce: true,
      headerType: 1
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});

  } catch (e) {
    console.error(e);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key }});
    await conn.reply(m.chat, '❌ حدث خطأ أثناء تنفيذ الأمر', m);
  }
};

handler.command = ['اغنيه'];
export default handler;