const handler = async (m, { conn }) => {
    const imageUrl = "https://files.catbox.moe/c5pkc1.jpg";
    const link1 = "https://wa.me/201500564191";

    // الرسالة الأولى: externalAdReply مع صورة كبيرة
    const adMessage = {
        text: "> بــ؏ــد غــيـآب طــوُيـل خـرجـت لَڪــم مِـن آلـجـحـيـم… إسـمـي آبـيـس بــوُت، مـطـوُريـنـي مــيــدوُ و شـيـطـآن آلإذآعـه اسـتـخـدم امـر (.اوامـر) لطلب الـقـائـمـة",
        contextInfo: {
            externalAdReply: {
                title: "｢🐥┊𝐀𝐁𝐘𝐒𝐒|𝐁𝐎𝐓┊⛄｣",
                body: "｢🧸┆𝐀𝐁𝐘𝐒𝐒|𝐁𝐎𝐓┆❄️｣",
                thumbnailUrl: imageUrl,
                mediaType: 1,
                renderLargerThumbnail: true,
                sourceUrl: link1
            }
        }
    };

    await conn.sendMessage(m.chat, adMessage, { quoted: m });

    // الرسالة الثانية: أزرار
    const buttons = [
        { buttonId: ".اوامر", buttonText: { displayText: "⌈🚀╎اوامر╎🚀⌋" }, type: 1 },
        { buttonId: "المطور", buttonText: { displayText: "⌈👑╎المطور╎👑⌋" }, type: 1 }
    ];

    const buttonMessage = {
        text: "اختر من الأزرار التالية:",
        buttons: buttons,
        footer: "> BY&RADIO",
        headerType: 1
    };

    await conn.sendMessage(m.chat, buttonMessage, { quoted: m });
};

handler.command = /^بوت$/i;

export default handler;