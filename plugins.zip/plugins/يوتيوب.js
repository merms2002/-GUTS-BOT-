import axios from 'axios';

const handler = async (m, { conn, args, usedPrefix, command }) => {
  const url = args[0];
  if (!url || !/^https?:\/\//.test(url)) return m.reply(`✧ ارسل رابط: ${usedPrefix}${command} https://...`);

  await conn.sendMessage(m.chat, { react: { text: '🔎', key: m.key } });

  try {
    const { data: info } = await axios.get('https://youtube-download-api.matheusishiyama.repl.co/info/', {
      params: { url }
    });

    const buttons = [
      { buttonId: `${usedPrefix}${command} ${url} mp4`, buttonText: { displayText: '📹 تحميل فيديو' }, type: 1 },
      { buttonId: `${usedPrefix}${command} ${url} mp3`, buttonText: { displayText: '🎵 تحميل صوت' }, type: 1 },
    ];

    await conn.sendMessage(m.chat, {
      image: { url: info.thumbnail },
      caption: `🎬 العنوان: ${info.title}`,
      footer: 'اختر التحميل:',
      buttons,
      headerType: 4
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    m.reply('❌ تعذّر الحصول على معلومات الفيديو.');
  }
};

const dlHandler = async (m, { conn, args }) => {
  const url = args[0];
  const format = args[1]; // mp4 أو mp3
  if (!url || !format) return m.reply('❗ خطأ في الأمر.');

  const path = format === 'mp3' ? 'mp3' : 'mp4';
  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  try {
    const response = await axios.get(`https://youtube-download-api.matheusishiyama.repl.co/${path}/`, {
      params: { url },
      responseType: 'stream'
    });

    const type = format === 'mp3' ? 'audio' : 'video';
    const payload = {
      [type]: { url: response.config.url },
      mimetype: format === 'mp3' ? 'audio/mpeg' : undefined,
      fileName: format === 'mp3' ? `${Date.now()}.mp3` : `${Date.now()}.mp4`
    };

    await conn.sendMessage(m.chat, payload, { quoted: m });

  } catch (e) {
    console.error(e);
    m.reply('❌ فشل في تحميل الملف.');
  }
};

handler.command = /^يوتيوب$/i;
dlHandler.command = /^يوتيوب$/i;

export default [handler, dlHandler];